<div class="divider"></div>
<div class="container">
  <div class="row">
    <div class="col-md-12">
<div class="container">
      <?=form_open()?>
      <div class="form-group">
        <label> Username </label>
        <input type="text" name="username" class="form-control" placeholder="username" required>
        <?php if($errors->hasError('username')): ?>
        <?= $errors->showError('username') ?>
        <?php endif; ?>
      </div>

      <div class="form-group">
        <label> Password </label>
        <input type="password" name="password" class="form-control" placeholder="password" required>
        <?php if($errors->hasError('password')): ?>
        <?= $errors->showError('password') ?>
        <?php endif; ?>
      </div>


      <button type="submit" class="btn btn-primary">Masuk</button>

      <?=form_close()?>
      </div>
    </div>
  </div>
</div>