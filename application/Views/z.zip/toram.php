
        <div class="my-3 my-md-5">
          <div class="container">
        <h1>Selamat datang!</h1>

        Jelajahi informasi Toram Online, senjata, armor, drop dan lainnya.

       <hr>
        <?= view('cari')?>
      </div>
    </div>